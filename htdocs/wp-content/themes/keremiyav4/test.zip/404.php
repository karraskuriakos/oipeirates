<?php get_header();?>
<div id="content">
	<div class="olmayansayfa">
		<?php echo keremiya_hata_404; ?>
		<p><?php echo keremiya_hata_404_mesaj; ?></p>
	</div>
</div>
</div>
<div style="clear:both;"></div>
<div class="footborder"></div>
<?php get_footer();?>