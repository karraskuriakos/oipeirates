<?php wp_footer(); ?>
<div id="footer">
        	<div class="footer clearfix">
		<div class="footerleft">
			<?php if(get_option('keremiya_footer_left')) { echo get_option('keremiya_footer_left'); } else { echo 'Copyright &copy; '.date('Y').' <a href="'.get_settings('home').'">Tainies Online Greek Subs - OiPeirates</a>'; echo "</br>";  } if(get_option('keremiya_analytics')) { echo get_option('keremiya_analytics'); } ?>
		</div> 
<!-- '.get_bloginfo('name').' -->
		<div class="footeright">     
</div>
</div>
</div>
</div>


<script type='text/javascript' src='//muqson0kgr.com/d241754c38147675d7877067da57081f/invoke.js'></script>

</body>
</html>