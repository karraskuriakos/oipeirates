<?php get_header();?>
<script async src="https://cdn.onesignal.com/sdks/OneSignalSDK.js"></script>
<script>
    var OneSignal = window.OneSignal || [];
    OneSignal.push(["init", {
        appId: "788ac242-4a51-4728-bdf5-f6ddb518b9b9",
        autoRegister: true,
        notifyButton: {
            enable: true,
            /* Required to use the notify button */
            displayPredicate: function() {
                return OneSignal.isPushNotificationsEnabled()
                    .then(function(isPushEnabled) {
                        return !isPushEnabled;
                    });
            },
            size: 'medium',
            /* One of 'small', 'medium', or 'large' */
            theme: 'default',
            /* One of 'default' (red-white) or 'inverse" (white-red) */
            position: 'bottom-right',
            /* Either 'bottom-left' or 'bottom-right' */
            prenotify: true,
            /* Show an icon with 1 unread message for first-time site visitors */
            showCredit: false,
            /* Hide the OneSignal logo */
            text: {
                'tip.state.unsubscribed': 'Εγγραφή στις ενημερώσεις μας.',
                'tip.state.subscribed': "Γραφτήκατε στις ενημερώσεις μας",
                'tip.state.blocked': "Έχετε αποκλείσει τις ενημερώσεις",
                'message.prenotify': 'Κάντε κλικ για να εγγραφείτε στις ενημερώσεις',
                'message.action.subscribed': "Ευχαριστούμε για την εγγραφή σας!",
                'message.action.resubscribed': "Έχετε εγγραφεί στις ενημερώσεις",
                'message.action.unsubscribed': "Δεν θα λάβετε ξανά ενημερώσεις",
                'dialog.main.title': 'Διαχείριση των ειδοποιήσεων ιστότοπου',
                'dialog.main.button.subscribe': 'Εγγραφή',
                'dialog.main.button.unsubscribe': 'Διαγραφή',
                'dialog.blocked.title': 'Απεμπλοκή ενημερώσεων',
                'dialog.blocked.message': "Ακολουθήστε αυτές τις οδηγίες για να επιτρέψετε τις ενημερώσεις μας:"
            }
        },
        welcomeNotification: {
            disable: true
        }
    }]);
</script>
<div id="fb-root"></div>
<script async>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/el_GR/sdk.js#xfbml=1&version=v3.1&appId=562307960475160&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<script type="text/javascript"> 
     var adfly_id = 13307935; 
    var adfly_advert = 'int'; 
    var popunder = false; 
    var adfly_protocol = 'https';
    var adfly_nofollow = true;
    var domains = ['streamcloud.eu', 'vidd.tv', 'vidto.me', 'flashx.tv', 'streamin.to', 'linkbucks.com', 'zettahost.tv', 'exashare.com', 'yourvideohost.com', 'hdvid.tv', 'vidzi.tv', 
'openload.io', 'sh.st', 'openload.co', 'greevid.com'];
</script> 
<script data-cfasync="true" src="https://img.oipeirates.tv/test02.js"></script>


<script type="text/javascript">
            var adlinkfly_url = 'https://xshort.xyz/';
            var adlinkfly_api_token = '83edc2f1879e1f5edeb0cc80435c4864e4bf57c5';
            var adlinkfly_advert = 2;
    var adlinkfly_domains = ['streamcloud.eu','vidd.tv','vidto.me','flashx.tv','streamin.to','linkbucks.com','zettahost.tv','exashare.com','yourvideohost.com','hdvid.tv','vidzi.tv','openload.io','sh.st','openload.co','greevid.com','ay.gy','adf.ly','hdvid.live'];
        </script>
        <script src='https://xshort.xyz/js/full-page-script.js'></script>


<div id="content">
<div class="leftC">
<div class="filmborder">
	<div class="filmcontent">




	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<h1><a href="https://www.google.gr/search?hl=gr&q=site:oipeirates.tv <?php the_title(); ?>" title="<?php the_title(); ?>" target="blank;"><img alt="google" src="<?php bloginfo('template_directory'); ?>/images/google.png"/></a> <?php the_title() ?> <?php keremiya_breadcrumbs(); ?></h1>
		<?php if(get_option('keremiya_r_a') == 'On') { ?>
		<?php include(TEMPLATEPATH . '/videoreklam.php'); ?>
		<?php } else {?>
				<div class="keremiya_part">
		<?php bilgi_part(); ?>
		<?php if ( wp_link_pages('echo=0') ) : ?>
		<?php if(get_post_meta($post->ID, 'partsistemi', true) == 'Manuel') { ?>
		<?php keremiya_part_sistemi(''); ?>
		<?php } else { ?>
		<?php $sayfalama = get_option('keremiya_part_iki'); wp_link_pages('before=&pagelink=<span>'. $sayfalama .' %</span>&after=<span class="keros"><a href="#respond">Yorum yap</a></span>'); ?>
		<?php } ?> 
		<?php endif; ?>
		</div>
		<div class="clear"></div>
		<div class="filmicerik">
<!-- <h3  align="center" style="color:orange;" style="font-family: Arial;"><strong>TAINIES ONLINE GREEK SUBS</strong></h3> -->
<center>
<script type="text/javascript" data-cfasync="false" src="/prts.nln.php?s=Z3Ivb2lwZWlyYXRlcy92cCMyMDE4MDkyNw=="></script>
</center>


		<?php the_content(); ?>
<center>
	<script type="text/javascript" data-cfasync="false" src="/prts.nln.php?s=Z3Ivb2lwZWlyYXRlcy80Njg2MCMyMDE4MDcyMw=="></script>
	<script type="text/javascript" data-cfasync="false" src="/prts.nln.php?s=Z3Ivb2lwZWlyYXRlcy9jZjcyODkwIzIwMTgwNzIz"></script>
</center>
				    			    </div>
<div><center><font size="4" color="gray">Ακολουθείστε μας στο > <a href="https://www.instagram.com/oipeirates/" target="_blank"><font color="red">Instagram</font></a> < </font></center></div>
<br>
	<?php } ?>
		<div id="alt">
			<div class="facebok"><iframe src="//www.facebook.com/plugins/like.php?href=<?php the_permalink(); ?>&amp;send=false&amp;layout=standard&amp;width=390&amp;show_faces=false&amp;action=like&amp;colorscheme=dark&amp;font&amp;height=35" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:390px; height:35px;" allowTransparency="true"></iframe></div>
			<div class="facepaylas"><script>function fbs_click(){u=location.href;t=document.title;window.open('http://www.facebook.com/sharer.php?u='+encodeURIComponent(u)+'&t='+encodeURIComponent(t),'sharer','toolbar=0,status=0,width=626,height=436');return false;}</script><a rel="nofollow" class="sh-face" href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" onclick="return fbs_click()" target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/facebook_paylas.png" /></a></div>
			<?php if(function_exists('the_views')) { echo '<div class="izlenme"><div class="ok">'; the_views(); echo '</div>'; echo '</div>'; } ?>
		</div>	
		<?php endwhile; else: ?>
		<?php endif; ?>
	</div>
</div>
<?php if(get_option('keremiya_r_b') == 'On'): ?>
	<div class="bireklam">
		<?php echo get_option('keremiya_r_b_b'); ?>
	</div>
<?php endif; ?>
<?php if(get_option('keremiya_benzer_var') == 'On'): ?>
<div class="filmborder">
	<div class="filmcontent">
		<div class="yazitip"><?php echo keremiya_film_benzer; ?></div>
			<?php $categories = get_the_category($post->ID);
			$keremiya_show = get_option('keremiya_benzer_filmler');
			if ($categories) { $category_ids = array();
			foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
			$args=array(
				  'category__in' => $category_ids,
				  'post__not_in' => array($post->ID),
				  'showposts'=> $keremiya_show, // Gösterilecek benzer yazı sayısı
				  'caller_get_posts'=>1
			   );
			$my_query = new wp_query($args); if( $my_query->have_posts() ) { while ($my_query->have_posts()) { $my_query->the_post();?>
			<?php include (TEMPLATEPATH . '/film.php'); ?>
			<?php } } wp_reset_query(); } ?>
	</div>
</div>
<?php endif; ?>
	<div class="filmborder">
	<div class="filmcontent">
         <div class="yazitip"><?php echo keremiya_film_yorumlar; ?> <span>Θέλετε να σχολιάσετε?</span></div>
<div data-width="895" colorscheme="dark" class="fb-comments" data-href="<?php the_permalink(); ?>" data-numposts="5"></div>
	</div>

</div>
</div>
<?php include ('sidebar-single.php'); ?>
</div>
</div>
<div style="clear:both;"></div>
<div class="footborder"></div>
<?php get_footer();?>



<!-- advertising fZDT9VG0FJFI_rA5vROTrKoCwOX1VsDfmFRaRKYPLMEuhM2O3oABxGi8JbBC8EFF1B-v76NgrldMjxenquSxAQ==-->
							<script data-cfasync="false"  id="clevernt" type="text/javascript">
							 (function (document, window) {
                var c = document.createElement("script");
                c.type = "text/javascript"; c.async = !0; c.id = "CleverNTLoader30237";  c.setAttribute("data-target",window.name); c.setAttribute("data-callback","put-your-callback-macro-here");
                c.src = "//clevernt.com/scripts/c84d57194e5a49c7e261e670754d017d.min.js?20190313=" + Math.floor((new Date).getTime());
                var a = !1;
                try {
                    a = parent.document.getElementsByTagName("script")[0] || document.getElementsByTagName("script")[0];
                } catch (e) {
                    a = !1;
                }
                a || ( a = document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]);
                a.parentNode.insertBefore(c, a);
            })(document, window);
                                </script>
                                <!-- end advertising -->
